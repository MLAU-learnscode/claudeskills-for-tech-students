---
name: tech-consulting
description: Solve, drill or review any tech consulting or digital transformation case (case competitions, assessment centres, interview cases) with a vendor-neutral 8-step flow.
---

# Tech consulting case flow

Use for any tech consulting, digital transformation, IT strategy or solution-selling case: written case studies, group assessment centres, case competitions, verbal interview cases, or reviewing a case deck.

Tech consulting = management consulting diagnosis + solution design + delivery planning.
Memory hook: **Frame, Diagnose (PPT+D), Quantify, Design, Justify, Phase, De-risk, Synthesise.**

## Style rules
- Peer-to-peer, direct. Never use em dashes.
- Pair every term with its proper name plus a short layman breakdown.
- Tables for comparisons. Keep each step bite-sized.
- Separate facts stated in the brief from assumptions; label every assumed number.
- Stay vendor-neutral. Only name specific products or platforms if the case, company or user specifies one (see Tailoring).

## Pick a mode first
| Mode | When | How to run it |
| --- | --- | --- |
| Solve | User wants a worked answer | Run all 8 steps, concise, with a final SCR storyline |
| Drill | User is practising | Give or take a prompt; user attempts one step at a time; critique with the checklist before moving on. Do not hand over the answer upfront |
| Review | User shares a deck or answer | Score against the checklist; give the top 3 fixes first |
| Verbal interview case | Interviewer-led, spoken | Compress: frame, tree, 2 to 3 causes, recommendation, value, risks, in under 5 minutes talking time |
| Prep | Before an assessment | Research the firm and likely case themes, then build a tailored cheat sheet using this flow |

If the mode is unclear, ask one short question.

## Step 1: Frame (~10% of time)
Check the brief for:
- Client vs buyer (CFO, CIO, COO, CEO care about different things; the asker sets your lead)
- The ask vs the real problem (a requested solution like "modernise" or "implement AI" is not the problem)
- Success metric (which number moves)
- Constraints (budget, timeline, legacy systems, regulation, skills)
- Hidden clues (numbers given matter; deadlines, growth plans or regulation are the "why now")

Output: one key question with outcome, scope and timeframe.

## Step 2: Diagnose with a MECE issue tree
Levels = depth. Each level answers a different question and is MECE (mutually exclusive, collectively exhaustive) on its own.

| Level | Question |
| --- | --- |
| L0 Key question | What are we solving? |
| L1 Outcome driver | Which business math moves (revenue, cost, risk, capital)? |
| L2 Where it happens | Which process chain leaks? |
| L3 Root cause | People / Process / Technology / Data |
| L4 Evidence | What data would prove it? |

Common process chains: O2C (order to cash), P2P (procure to pay), R2R (record to report), Plan-to-fulfil, Hire-to-retire, Lead-to-cash, Customer onboarding / service. Use industry-specific chains when the case calls for them (e.g. claims processing in insurance, KYC onboarding in banking).

Hybrid method: brainstorm root causes bottom-up from symptoms, then slot each into the tree to catch gaps, overlaps and mixed depth (symptoms sitting beside causes).
MECE trap: file a root cause where its fix lives (software fix = Technology, redesigned steps = Process).
End with a hypothesis to test.

## Step 3: Quantify and prioritise
- Baseline each pain in numbers with stated assumptions.
- Impact vs effort: quick wins first, strategic bets phased, drop low impact.
- 80/20: keep the 2 or 3 causes carrying most of the value.

## Step 4: Design the future state
Order: to-be process, then capabilities, then architecture. Tech before process is the classic mistake.

| Layer | What it is |
| --- | --- |
| Core / system of record | Single source of truth for transactions (ERP, core banking, CRM) |
| Integration | How systems talk (APIs, middleware, event streams) |
| Data | One trusted view for reporting and AI (warehouse, lakehouse, master data) |
| Intelligence / automation | Work the machine does (RPA, ML models, AI agents, workflow rules) |
| Experience | What users touch (portals, mobile apps, dashboards) |

State explicitly:
- Build vs buy vs extend (buy commodity capability, extend where needed, build only what differentiates)
- Keep the core standard (configure, don't heavily customise, so upgrades stay cheap)
- Cloud vs on-prem vs hybrid, only if it matters to the constraints
- Security, compliance and data privacy where regulation applies

## Step 5: Business case
Four value levers: revenue up, cost down, risk down, capital freed (working capital).
Set against TCO (total cost of ownership: licences, implementation, training, run costs over 3 to 5 years), then ROI and payback. Show assumptions; round numbers.

## Step 6: Roadmap
- Phase 0, quick wins (0 to 3 months): visible early value
- Phase 1, core (3 to 12 months): foundation, piloted in one unit before rollout
- Phase 2, scale and intelligence (12 to 18+ months): automation, AI, expansion

Generic delivery lifecycle: Discover, Design, Build, Test, Deploy, Run. Note agile vs waterfall if relevant. Pilot first: lower risk, proof of value, internal success story.

## Step 7: Risks and change management
Reuse People / Process / Technology / Data to list risks, each with a mitigation.
Change plan: ADKAR (Awareness, Desire, Knowledge, Ability, Reinforcement).
Stakeholder map (power / interest): sponsor, champions or blockers, end users.

## Step 8: Synthesise
SCR (Situation, Complication, Resolution), answer first with the headline value number (Pyramid Principle). Slide titles are full-sentence takeaways.

Default storyline: exec summary, situation and objectives, root causes, future state, business value, roadmap, risks and change, next steps / ask.

## Group timing (scale to the time given; 90 minutes shown)
| Time | Step | Mode |
| --- | --- | --- |
| 0 to 10 | Frame | Together; agree the key question |
| 10 to 25 | Diagnose, prioritise | Together; pick top 2 or 3 causes |
| 25 to 60 | Design, business case, roadmap, risks | Split |
| 60 to 75 | Synthesise | Together |
| 75 to 90 | Rehearse | Hand-offs and likely Q&A |

Group behaviours assessors score: structuring without dominating, time-keeping, building on others, inclusion, rigour, synthesis, constructive challenge, commercial awareness.

## Tailoring
- **Firm-specific prep** (a vendor, consultancy or bank): map the firm's products or services onto the architecture layers and value levers, and learn its current strategy and recent news. Search for current facts rather than relying on memory.
- **Industry:** swap in that industry's process chains, KPIs and regulators.
- **Pure management consulting case:** keep Steps 1 to 3 and 8; treat technology as one lever among several.
- **SME client:** favour off-the-shelf SaaS, low TCO, fast payback and light change management.

## Critique checklist
- Key question names an outcome, scope and timeframe?
- Each tree level MECE and at a single depth?
- Numbers quantified with assumptions?
- Process before technology?
- Every solution element maps to a value lever?
- Pilot, risk list and stakeholder view present?
- Synthesis leads with the answer?
